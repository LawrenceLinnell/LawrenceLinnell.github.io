# Lawrence Linnell
#!/usr/bin/python
import json
from bson import json_util
from bson.json_util import dumps
import bottle
from bottle import Bottle, route, run, request, abort, get, post, put, delete, error
import pymongo
from pymongo import MongoClient

# Configure Port, Database and Collection
connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']

# Define Helper Functions
def insert_doc(doc):
    try:
        result=collection.save(doc)
    except ValidationError as ve:
        abort(400,str(ve))
    return result

def delete_doc(key, val):
    result = collection.remove({key:val})
    if not result:
        abort(404,'Document Not Found')
    return result

def get_document(key, value):
    doc = collection.find_one({key:value})
    return doc

# Define function to accept a string and return ticker values
def get_ticker(industry_name):
    return dumps(collection.find({"Industry": industry_name},{"_id":0,"Ticker": 1}), indent = 4)

# AGGREGATE PIPELINE FUNCTION:  Finds documents for which the input string matches
# the document key Sector and returns the total outstanding shares grouped
# by document key Industry.
def get_shares_by_sector(sector):
    return dumps(collection.aggregate([{"$match": {"Sector": sector}},
                                       {"$group": {"_id": "$Industry", "total_shares_outstanding":
                                                  {"$sum": "$Shares Outstanding"}}},
                                      ]
                                     ), indent = 4
                )
# set up URI paths for REST service

#--[ ERROR ]--------------------------------------------------------------------
@error(200)
def error_200(error):
    return 'OK\n'

@error(400)
def error_400(error):
    return 'INPUT DATA MISSING\n'

@error(404)
def error_404(error):
    return 'NOT FOUND\n'

@error(500)
def error_500(error):
    return 'INTERNAL SERVER ERROR\n'
  
#--[ CREATE ]---------------------------------------------------------------------
@route('/create', method = 'POST')
def insert_document():
    # Store the query data into line_input variable
    line_input = request.body.readline()
    # Translate Json data to python object
    doc = json.loads(line_input)
    # Verify document contains an id field
    if not doc.has_key("Ticker"):
        abort(400,"Missing Input Data: Ticker")
    # Attempt to save the document in the database
    try:
        insert_doc(doc)
    except Exception as e:
        abort(400, str(e))

#--[ READ   ]---------------------------------------------------------------------
@route('/read', method='GET')
def read_document():
    try:
        business = request.query.ticker
        result = collection.find_one({"Ticker": business})
        print(result)
    except Exception as e:
        abort(400, str(e))
        
    return json.loads(json.dumps(result, indent= 4, default= json_util.default))

#--[ UPDATE ]---------------------------------------------------------------------
@route('/update', method = 'GET')
def update_document():
    try:
        update_id = request.query.id
        update_result = int(request.query.result)
        if update_result >= 0:
            result = collection.update_one({"Ticker": update_id}, {"$set": {"result": update_result}})
            if not result:
                abort(404,"Document Not Found:  Possible wrong key value.")
        else:
            abort(400, "Value must be greater than zero.")
    except Exception as e:
        abort(400, str(e))

#--[ DELETE ]---------------------------------------------------------------------
@route('/delete', method='GET')
def delete_document():
    try:
        del_id = request.query.id
        result = collection.remove({'Ticker':del_id})
      
    except Exception as e:
        abort(400, str(e))
    return json.loads(json.dumps(result, indent= 4, default= json_util.default))

#--[ HI_LO_50_DAY_AVG ]-----------------------------------------------------------
@route('/hilo50', method = 'GET')
def hi50LoAvg():
    count = 0
    try:
        hi = float(request.query.hi)
        low = float(request.query.low)

        results = collection.find({"50-Day Simple Moving Average":{"$gte": low,"$lte": hi}})
            
        for result in results:
            count = count + 1

        return({"total":count})
      
    except Exception as e:
        abort(400, str(e))

#--[ Industry_Tickers ]-----------------------------------------------------------
@route('/getTickers', method = 'GET')
def industryTickers():
    try:
        industry = request.query.industry
        print(industry)
        return get_ticker(industry)

    except Exception as e:
        abort(400, str(e))
        
#--[ Get Outstanding Shares by Sector ]-------------------------------------------------------
@route('/getOutstandingShares', method = 'GET')
def getOutstandingShares():
    try:
        sector = request.query.sector
        print(sector)
        return get_shares_by_sector(sector)
      
    except Exception as e:
        abort(400, str(e))

#--[ ADVANCED QUERY: Stock Summary ]------------------------------------------------------------------------
@route('/stockSummary', method = 'GET')
def stockSummary():
    try:
        ticker = request.query.ticker
        return dumps(collection.find_one({"Ticker": ticker},
                                         {"_id":0,
                                          "P/S":1,
                                          "P/B":1,
                                          "Shares Outstanding":1}), indent = 2)

    except Exception as e:
        abort(400, str(e))

#--[ ADVANCED QUERY: Industry Top 10]------------------------------------------------------
@route('/industryTop10', method = 'GET')
def industryTop10():
    try:
        industry = request.query.industry
        return dumps(collection.find({"Industry": industry
                                     }
                                    ,
                                     {"_id":0,
                                      "Ticker":1,
                                      "Performance (Quarter)":1
                                      }
                                    )
                     .sort("Performance (Quarter)", pymongo.DESCENDING)
                     .limit(10)
                     ,indent = 2)

    except Exception as e:
        abort(400, str(e))

#--[ main ]-----------------------------------------------------------------------
if __name__ == '__main__':
    #app.run(debug=True)
    run(reloader= True,host='localhost', port=8080)