/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

import java.util.Scanner;
import java.util.ArrayList;

/**
 * CruiseList class manages the list of cruise objects and contains
 * associated methods.
 * @author Lawrence Linnell
 */
public class CruiseList {
	// Class Variables
	ArrayList<Cruise> cruiseList;
	ShipList shipList;
	ValidInput validInput;
	
/**
 * Constructor - Default object constructor.
 */
    CruiseList(ValidInput validInput, ShipList shipList) {
        cruiseList = new ArrayList<Cruise>();
	    this.validInput = validInput;
	    this.shipList = shipList;
        initializeCruiseList();     // initialize cruises
    }
	
/**
 * initializeCruiseList - Initialize cruise list.
 */
    public void initializeCruiseList() {
        Cruise newCruise = new Cruise("Southern Swirl",
      		                          "Candy Cane",
      		                          "Miami",
      		                          "Cuba",
      		                          "Miami");
        cruiseList.add(newCruise);
    }
    
 /**
 * addCruise - Adds a cruise to the cruiseList ArrayList.
 * @param cruiseName is a String that represents the name of the cruise.
 * @param shipName is a String that represents the name of the ship.
 * @param departure is a String that represents the port of departure.
 * @param destination is a String that represents the port of destination.
 * @param returnPort is a String that represents the port of return.
 */
    public void addCruise(String cruiseName,
                          String shipName,
                          String departure,
                          String destination,
                          String returnPort) {
	
	    Cruise newCruise = new Cruise(cruiseName,
		    	                      shipName,
			                          departure,
			                          destination,
			                          returnPort);
        cruiseList.add(newCruise);
    }
    
/**
 * addCruise - Add a new cruise to cruiseList
 *           - Verifies that the cruise is a new cruise not in cruiseList.
 *           - Verifies that the ship is active and available for the new cruise.
 * @param scnr is a valid Scanner object.
 */
    public void addCruise(Scanner scnr, ShipList shipList) {
	    //Variables
	    String newCruiseName      = "?";
	    String cruiseInSystemName = "?";
        String cruiseShipName     = "?";
	    String departurePort      = "?";
	    String destination        = "?";
	    String returnPort         = "?";
	    boolean cruiseFound     = false;
	    boolean verifyShip      = false;

        validInput.clearInputBuffer(scnr);
        
        try {
            //Get new cruise name.
            System.out.print("Enter the new cruise's name:");
	        newCruiseName = scnr.nextLine();

            //Check cruiseList for cruise name.
	        for(Cruise cruiseInSystem: cruiseList) {
    		    cruiseInSystemName = cruiseInSystem.getCruiseName();
	    	    //Verify that cruise does not already exist.
		        if(cruiseInSystemName.compareTo(newCruiseName) == 0) {
			        System.out.printf("%s already exists in the system.", newCruiseName);
		    	    cruiseFound = true;
			        break;
	    	    }
    	    }
	        
	        if(!cruiseFound) {
 	            System.out.printf("%nEnter the ship name: ");
	            cruiseShipName = scnr.nextLine();   		
		
	            verifyShip = shipList.shipActiveAvailable(cruiseShipName, cruiseList);

	            if(verifyShip) {
            	    System.out.printf("%nEnter the port of departure: ");
    	            departurePort = scnr.nextLine();

        	        System.out.printf("%nEnter the destination: ");
        	        destination = scnr.nextLine();

        	        System.out.printf("%nEnter the port of return: ");
	                returnPort = scnr.nextLine();

	                addCruise(newCruiseName,
                              cruiseShipName,
                              departurePort,
                              destination,
                              returnPort);

	                cruiseFound = false;//reset boolean to false for next input.
    	        }
	            else {
		            System.out.println("Please select another menu option.");
	            }
       	    }
        }

 	    catch(Exception excpt) {
 		    System.out.println("The following error message was reported:");
		    System.out.println(excpt.getMessage());
 		    System.out.println("Error occurred in method: addCruise ");
 		    validInput.clearInputBuffer(scnr);
 	    }
    }
    
/**
 * editCruise - Edit an existing cruise
 */
    public void editCruise() {
        // This method does not need to be completed
        System.out.println("The \"Edit Cruise\" feature is not yet implemented.");
    }

/**
 * getCruise - Returns cruise info on a given cruise name or prints not in system
 * @param searchCruise is a valid cruise name
 * @return string cruiseName
 */
    public String getCruise(String searchCruise) {
        if (cruiseList.size() < 1) {
            System.out.println("\nThere are no cruises in system.");
            return null;
        }

        for (Cruise eachCruise: cruiseList) {

    	    if(searchCruise.compareTo(eachCruise.getCruiseName()) == 0) {
                printDetailsColHeader();   	    	
                eachCruise.printCruiseDetails();
                return searchCruise;
    	    }
        }
    	System.out.println(searchCruise + " is not in the system.");
    return null;
    }
    
/**
 * printCruiseList - Prints a list of cruises from the cruiseList ArrayList.
 * @param listType: There are three different outputs based on the listType
 *     String parameter:
 *         list - prints a list of cruise names only
 *         details - prints detailed data on all cruises
 */
    public void printCruiseList(String listType) {
        if (cruiseList.size() < 1) {
            System.out.println("\nThere are no cruises to print.");
            return;
        }

        if (listType == "list") {
            System.out.println("\n\nCRUISE LIST");
            for (int i=0; i < cruiseList.size(); i++) {
                System.out.println(cruiseList.get(i));
            }
        }

        else if (listType == "details") {
        	printDetailsColHeader();
            for (Cruise eachCruise: cruiseList)
                eachCruise.printCruiseDetails();
        }

        else
            System.out.println("\n\nError: List type not defined.");
    }

/**
 * printDetailsColHeader - Prints the column headers for cruise details.
 */
    public void printDetailsColHeader() {
        System.out.println("\n\nCRUISE LIST - Details");
        System.out.println("---------------------------------------------" +
                           "---------------------------------------------");
        System.out.println("                                      |------" +
                           "----------------PORTS-----------------------|");
        System.out.print("CRUISE NAME         SHIP NAME           "        +
                         "DEPARTURE           DESTINATION         RETURN");
        System.out.println("\n--------------------------------------------"+
                           "---------------------------------------------");
    }
}