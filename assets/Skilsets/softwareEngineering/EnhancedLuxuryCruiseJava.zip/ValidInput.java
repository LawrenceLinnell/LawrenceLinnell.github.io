/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */
import java.util.Scanner;

/**
 * ValidInput class handles data verification methods related to user input
 * and output.
 * @author Lawrence Linnell
 */
public class ValidInput {
	
  /**
   * Constructor - Default object constructor.
   */
    ValidInput() {
    }
    
/**
 * clearInputBuffer - Clears the input buffer.
 * @param scnr is a valid Scanner object.
 */
    public void clearInputBuffer(Scanner scnr) {
  	scnr.nextLine();
  }
    
/**
 * pressEnterToContinue - Pauses the display until the user presses enter.
 * @param scnr is a valid Scanner object.
 */
    public void pressEnterToContinue(Scanner scnr) {  	    	
	System.out.printf("%nPress [ Enter ] to Continue.");
	scnr.nextLine();
}
    
/**
 * isANumber - Checks if string input is a number.
 * @param str is a valid string
 */
    public boolean isANumber(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i)) == false)
                return false;
        }
        return true;
    }
    
/**
 * isANumber - Checks if character input is a number.
 * @param character is a valid character
 */
    public boolean isANumber(char character) {
        if (Character.isDigit(character) == false)
                return false;
        return true;
    }  

/**
 * isInRange - Checks if an integer is in the given range.
 * @param number is a valid integer that is checked if between minRange and maxRange
 * @param minRange is a valid integer that represents lowest value of range
 * @param maxRange is a valid integer that represents maximum value of range
 */
    public boolean isInRange(int number, int minRange, int maxRange) {
        if (number >= minRange && number <= maxRange) {
            return true;
        }
        return false;
    }  
}

