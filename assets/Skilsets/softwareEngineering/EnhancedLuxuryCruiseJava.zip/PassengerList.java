/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

import java.util.ArrayList;
import java.util.Scanner;

/**
 * PassengerList class manages the list of passenger objects and contains
 * associated methods.
 * @author Lawrence Linnell
 */
public class PassengerList {
	// Class Variables
	ValidInput validInput;
	ArrayList<Passenger> passengerList;
	
/**
 * Constructor - Default object constructor.
 */
	PassengerList(ValidInput validInput) {
	    passengerList = new ArrayList<Passenger>();
	    this.validInput = validInput;
        initializePassengerList();  // initialize passengers
    }
	
/**
 * initializePassengerList - Initialize passenger list.
 */
	public void initializePassengerList() {
        Passenger newPassenger1 = new Passenger("Neo Anderson",
        		                                "Southern Swirl",
      	    	                                "STE");
        passengerList.add(newPassenger1);

        Passenger newPassenger2 = new Passenger("Trinity",
      	    	                                "Southern Swirl",
      		                                    "STE");
        passengerList.add(newPassenger2);

        Passenger newPassenger3 = new Passenger("Morpheus",
      	    	                                "Southern Swirl",
      		                                    "BAL");
        passengerList.add(newPassenger3);
    }
	
/**
 * addPassenger - Add a new passenger
 */
	public void addPassenger(CruiseList cruiseList) {
	    ArrayList<Cruise> cruises = cruiseList.cruiseList;

        Scanner newPassengerInput = new Scanner(System.in);
        System.out.println("Enter the new passenger's name: ");
        String newPassengerName = newPassengerInput.nextLine();

        // Ensure new passenger name does not already exist.
        for (Passenger eachPassenger: passengerList) {
            if (eachPassenger.getPassengerName().equalsIgnoreCase(newPassengerName)) {
                System.out.println("That passenger is already in the system. "
            	                  +"Exiting to menu...");
                newPassengerInput.close();
                return; // quits addPassenger() method processing
            }
        }

        // get cruise name for passenger
        System.out.println("Enter cruise name: ");
        String newCruiseName = newPassengerInput.nextLine();

        // ensure cruise exists
        for (Cruise eachCruise: cruises) {
        	
            if (eachCruise.getCruiseName().equalsIgnoreCase(newCruiseName)) {
                // cruise does exist
            }
            
            else {
                System.out.println("That cruise does not exist in the system. "
            	                  +"Exiting to menu...");
                newPassengerInput.close();
                return; // quits addPassenger() method processing
            }
        }

        // get room type
        System.out.println("Enter Room Type (BAL, OV, STE, or INT: ");
        String room = newPassengerInput.nextLine();
        // validate room type
        if ((room.equalsIgnoreCase("BAL")) || (room.equalsIgnoreCase("OV")) ||
            (room.equalsIgnoreCase("STE")) || (room.equalsIgnoreCase("INT"))) {
            // validation passed - add passenger
            Passenger newPassenger = new Passenger(newPassengerName,
        	    	                               newCruiseName,
        		                                   room.toUpperCase());
            passengerList.add(newPassenger);
        }
        
        else {
            System.out.println("Invalid input. Exiting to menu...");
            newPassengerInput.close();
            return; // quits addPassenger() method processing
        }
        newPassengerInput.close();
    }
	
/**
 * editPassenger - Edit an existing passenger
 */
	public void editPassenger() {
        // This method does not need to be completed
        System.out.println("The \"Edit Passenger\" feature is not yet implemented.");
    }

/**
 * getPassenger - Returns passenger info on a given passenger name or prints not in system
 * @param searchPassenger is a valid passenger name
 * @return string is a valid passenger name or null if not in system
 */
    public String getPassenger(String searchPassenger) {
        if (passengerList.size() < 1) {
            System.out.println("\nThere are no passengers in the system.");
            return null;
        }

        for (Passenger eachPassenger: passengerList) {

	        if(searchPassenger.compareTo(eachPassenger.getPassengerName()) == 0) {
	            printDetailsColHeader();   	    	
	            eachPassenger.printPassenger();
	            return searchPassenger;
	        }
	    }
	    System.out.println(searchPassenger + " is not in the system.");
	    return null;
	}
	    
/**
 * printPassengerList - Prints a list of passengers with cruise and room data.
 */
	public void printPassengerList() {
        if (passengerList.size() < 1) {
            System.out.println("\nThere are no passengers to print.");
            return;
        }
        
        printDetailsColHeader();
        
        for (Passenger eachPassenger: passengerList)
            eachPassenger.printPassenger();
    }
	
/**
 * printDetailsColHeader - Prints the column headers for passenger details.
 */
    public void printDetailsColHeader() {
        System.out.println("\n\nPASSENGER LIST");
        System.out.println("-----------------------------------------------------");
        System.out.print("PASSENGER NAME      CRUISE              ROOM TYPE");
        System.out.println("\n-----------------------------------------------------");
    }
}