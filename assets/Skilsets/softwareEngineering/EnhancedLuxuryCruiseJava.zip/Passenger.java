/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

/**
 * Passenger class creates a passenger object and manages the data
 * associated with a passenger.
 * @author Lawrence Linnell
 */
public class Passenger {

    // Class Variables
    private String passengerName;
    private String passengerCruise;
    private String passengerRoomType;


    // Constructor - default
    Passenger() {
    }

    // Constructor - full
    Passenger(String passengerName, String passengerCruise, String passengerRoomType) {
        this.passengerName = passengerName;
        this.passengerCruise = passengerCruise;
        this.passengerRoomType = passengerRoomType; // should be BAL, OV, STE, or INT
    }

    // Accessors
    public String getPassengerName() {
        return passengerName;
    }

    public String getPassengerCruise() {
        return passengerCruise;
    }

    public String getPassengerRoomType() {
        return passengerRoomType;
    }

    // Mutators
    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public void setPassengerCruise(String passengerCruise) {
        this.passengerCruise = passengerCruise;
    }

    public void setPassengerRoomType(String passengerRoomType) {
        this.passengerRoomType = passengerRoomType;
    }

    // print method
    public void printPassenger() {
    	// Variables
        int spaceCount;
        String spaces1 = "";
        String spaces2 = "";
        spaceCount = 20 - passengerName.length();
        
        for (int i = 1; i <= spaceCount; i++) {
            spaces1 = spaces1 + " ";
        }
        
        spaceCount = 20 - passengerCruise.length();
        
        for (int i = 1; i <= spaceCount; i++) {
            spaces2 = spaces2 + " ";
        }

        System.out.println(passengerName + spaces1 + passengerCruise + spaces2 +
                passengerRoomType);
    }

    // method added to print passenger's name vice memory address
    @Override
    public String toString() {
        return passengerName;
    }
}
