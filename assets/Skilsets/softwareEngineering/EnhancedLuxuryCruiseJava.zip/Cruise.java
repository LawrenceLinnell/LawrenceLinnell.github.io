/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

/**
 * Cruise class creates a cruise object with data related to cruises and
 * manages the data associated with cruises.
 * @author Lawrence Linnell
 */
public class Cruise {

    // Class Variables
    private String cruiseName;
    private String cruiseShipName;
    private String departurePort;
    private String destination;
    private String returnPort;
    
/**
 * Constructor - Default object constructor.
 */
    Cruise() {
    }
    
/**
 * Constructor - Full parameterized object constructor.
 * @param cruiseName is a String that represents the name of the cruise.
 * @param sShipName is a String that represents the name of the ship.
 * @param sDeparture is a String that represents the port of departure.
 * @param sDestination is a String that represents the destination port.
 * @param sReturn is a String that represents the port of return.
*/
    Cruise(String cruiseName,
    	   String shipName,
    	   String departure,
    	   String destination,
    	   String returnPort) {
        this.cruiseName     = cruiseName;
        this.cruiseShipName = shipName;
        this.departurePort  = departure;
        this.destination    = destination;
        this.returnPort     = returnPort;
    }
    
/**
 * Getters - The following methods are used to get the value from
 *           the objects given variable.
 */
    public String getCruiseName() {
        return cruiseName;
    }

    public String getCruiseShipName() {
        return cruiseShipName;
    }

    public String getDeparturePort() {
        return departurePort;
    }

    public String getDestination() {
        return destination;
    }

    public String getReturnPort() {
        return returnPort;
    }
    
/**
 * Setters - The following methods are used to set the object variables.
 */
    public void setCruiseName(String cruiseName) {
        this.cruiseName = cruiseName;
    }

    public void setCruiseShipName(String shipName) {
        this.cruiseShipName = shipName;
    }

    public void setDeparturePort(String departure) {
        this.departurePort = departure;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setReturnPort(String returnPort) {
        this.returnPort = returnPort;
    }
    
/**
 * printCruiseDetails - Prints the details of the cruise.
 *                    - Data is placed in columns that correspond to the variables.
 */
    public void printCruiseDetails() {
    	System.out.printf("%-19s %-19s %-19s %-19s %-19s\n",
    			           cruiseName,
    			           cruiseShipName,
    			           departurePort,
    			           destination,
    			           returnPort);
    }
    
/**
 * toString - method added to print ship's name vice memory address
 * @return is a String type of the cruiseName variable.
 */
    @Override
    public String toString() {
        return cruiseName;
    }
}