import java.util.*;

/**********************************************************************
 * Program:    Sort.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 31, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

/**
 * Sort class contains the associated methods used for sorting various
 * objects. Currently only a quickSort implementation is used to sort
 * the ArrayList of shipList objects based on their shipName.* 
 * @author Lawrence Linnell
 */
public class Sort {

	public ShipList shipList;

	/***
	 * Default Constructor 
	 */
	public Sort() {
	}
	
	/***
	 * quickSort algorithm recursively sorts a list based on
	 *           the start and end indexes compared to the pivot
	 *           index.  If the value of the index is greater than
	 *           the pivot value then the data is moved to the right
	 *           of the pivot.  If the value of the index is less
	 *           than the value of the pivot is moved to the left of
	 *           the pivot value.
	 * @param shipList - a valid ShipList object containing an ArrayList
	 * @param left - left most index to compare with pivot value
	 * @param right - right most index to compare with pivot value
	 */
	private void quickSort(ShipList shipList, int start, int end) {
        // If there is more than one element then begin sort algorithm.
		if (start < end) { 

			// Declare and initialize array position holders.
		    int pivot = start;
		    int left = start + 1;
		    int right = end;

		    // Get ship names to be sorted and store in respective variable
		    // for comparison.
		    String rightName = shipList.shipList.get(right).getShipName();
		    String leftName  = shipList.shipList.get(left).getShipName();
		    String pivotName = shipList.shipList.get(pivot).getShipName();
		    
		    // Convert Strings to Uppercase for comparison since algorithm
		    // relies on ASCII codes.  This prevents words starting with a
		    // lowercase letter from being incorrectly sorted.
		    rightName.toUpperCase();
		    leftName.toUpperCase();
		    pivotName.toUpperCase();
		    
		    while (true) {
			    //move right pointer
			    while (right > left && (rightName.compareTo(pivotName) > 0)) {
				    right--;
				    rightName = shipList.shipList.get(right).getShipName();
				    rightName.toUpperCase();
			    }
                //move left pointer
			    while (left < right && (leftName.compareTo(pivotName) <= 0)) {
				    left++;
				    leftName  = shipList.shipList.get(left).getShipName();
				    
				    // Uppercase ensures case insensitive comparison
				    leftName.toUpperCase();
				}
			    // Swap values of Arraylist when left and right pointers
			    // are unable to move
                if (left < right) {
                    Collections.swap(shipList.shipList, left, right);
				    leftName  = shipList.shipList.get(left).getShipName();
				    rightName = shipList.shipList.get(right).getShipName();
				    
				    // Uppercase ensures case insensitive comparison
				    leftName.toUpperCase();
				    rightName.toUpperCase();
			    }
                // swap pivot object into proper location and recursively
                // call quicksort on sub arrays.
                else {
                	Collections.swap(this.shipList.shipList, pivot, left);
		            quickSort(shipList, start, left - 1);
		            quickSort(shipList, left + 1, end);
		            return;
                }
		    }
        }
	}

	/***
	 * sortShips - Handler method used to sort the shipList array.
	 * @param shipList - a valid ShipList object
	 * @return - a valid ShipList object
	 */
	public ShipList sortShips(ShipList shipList) {
		this.shipList = shipList;
		quickSort(this.shipList, 0, this.shipList.shipList.size() - 1);
		return this.shipList;
	}
}