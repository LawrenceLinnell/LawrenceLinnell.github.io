/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

/**
 * Ship class creates a ship object with data related to ships and
 * manages the data associated with ships.
 * @author Lawrence Linnell
 */
public class Ship {

    // Class Variables
    private String shipName;
    private int roomBalcony;
    private int roomOceanView;
    private int roomSuite;
    private int roomInterior;
    private boolean inService;

    // Constructor - default
    Ship() {
    }

    // Constructor - full
    Ship(String name, int balcony, int oceanView,
         int suite, int interior, boolean inService) {
    	this.shipName = name;
    	this.roomBalcony = balcony;
    	this.roomOceanView = oceanView;
    	this.roomSuite = suite;
    	this.roomInterior = interior;
        this.inService = inService;
    }

    // Accessors
    public String getShipName() {
        return shipName;
    }

    public int getRoomBalcony() {
        return roomBalcony;
    }

    public int getRoomOceanView() {
        return roomOceanView;
    }

    public int getRoomSuite() {
        return roomSuite;
    }

    public int getRoomInterior() {
        return roomInterior;
    }

    public boolean getInService() {
        return inService;
    }

    // Mutators
    public void setShipName(String shipName) {
    	this.shipName = shipName;
    }

    public void setRoomBalcony(int roomBalcony) {
    	this.roomBalcony = roomBalcony;
    }

    public void setRoomOceanView(int roomOceanView) {
    	this.roomOceanView = roomOceanView;
    }

    public void setRoomSuite(int roomSuite) {
    	this.roomSuite = roomSuite;
    }

    public void setRoomInterior(int roomInterior) {
    	this.roomInterior = roomInterior;
    }

    public void setInService(boolean inService) {
    	this.inService = inService;
    }

    // print method
    public void printShipData() {
        System.out.printf("%-20s%-4s%-4s%-4s%-8s%-5s%n",
        		            shipName,
        		            roomBalcony,
        		            roomOceanView,
        		            roomSuite,
        		            roomInterior,
        		            inService);
    }

    // method added to print ship's name vice memory address
    @Override
    public String toString() {
        return shipName;
    }
}
