/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * ShipList class manages the list of ship objects and contains
 * associated methods.
 * @author Lawrence Linnell
 */
public class ShipList {
	// Class Variables
	ArrayList<Ship> shipList;
	ValidInput validInput;

/**
 * Constructor - Default object constructor.
 */
	ShipList(){
		shipList = new ArrayList<Ship>();
	}
	
/**
 * Constructor - Parameterized object constructor.
 */
    ShipList(ValidInput validInput) {
	  shipList = new ArrayList<Ship>();
	  this.validInput = validInput;
      initializeShipList();       // initialize ships
    }
    
/**
 * initializeShipList - Initialize ship list
 */
    public void initializeShipList() {
        addShipToList("Candy Cane", 20, 40, 10, 60, true);
        addShipToList("Peppermint Stick", 10, 20, 5, 40, true);
        addShipToList("Bon Bon", 12, 18, 2, 24, false);
        addShipToList("Candy Corn", 12, 18, 2, 24, false);
    }
    
/**
 * addShipToList - Custom method to add ships to the shipList ArrayList.
 * @param name is a String that represents the name of the ship.
 * @param balcony is an integer that represents the number of rooms with a balcony.
 * @param oceanView is an integer that represents the number of rooms with an ocean view.
 * @param suite is an integer that represent the number of bedroom suites
 * @param interior is an integer that represents the number of interior rooms.
 * @param inService is a boolean value that represents if a ship is in service when true.
 */
    public void addShipToList(String name,
		                         int balcony,
		                         int oceanView,
                                 int suite,
                                 int interior,
                                 boolean inService) {
	
        Ship newShip = new Ship(name,
    	                        balcony,
    		                    oceanView,
    		                    suite,
    		                    interior,
    		                    inService);
        shipList.add(newShip);
    }
    
/**
 * addShip - Add a New Ship to the system.
 *         - Ensures ship does not already exist in our system.
 *         - Ensures all class variables are populated.
 * @param scnr is a valid Scanner object.
 */
    public void addShip(Scanner scnr) {
	    //Variables
	    int balcony   = 0; //Number of rooms with a balcony.
	    int oceanView = 0; //Number of rooms with an ocean view.
	    int suite     = 0; //Number of rooms with a suite.
	    int interior  = 0; //Number of rooms on interior of ship.
	    char inService = '?'; //Ship in service char input.
	    String newShipName      = "?";
	    String shipInSystemName = "?";    	
	    boolean isInService    = false;
	    boolean isShipInSystem = false;


	    validInput.clearInputBuffer(scnr);
	
        try {
 	        //Get new ship name.     		
	        System.out.print("Enter the new ship's name:");
	        newShipName = scnr.nextLine();

            //Check ship array for ship name.
    	    for(Ship shipInSystem: shipList) {
	    	    shipInSystemName = shipInSystem.getShipName();
		        if(shipInSystemName.compareTo(newShipName) == 0) {
    			    System.out.printf("%s already exists in the system.",
	    		    		           newShipName);
		    	    isShipInSystem = true;
			        break;
		        }
	        }
	        if(!isShipInSystem) {
	            System.out.printf("%nEnter the number of rooms with a balcony: ");
	            balcony = scnr.nextInt();

        	    System.out.printf("%nEnter the number of rooms with an ocean view: ");
        	    oceanView = scnr.nextInt();

                System.out.printf("%nEnter the number of suites: ");
            	suite = scnr.nextInt();

            	System.out.printf("%nEnter the number of rooms on the "
        		    	         + "interior of the ship: ");
	            interior = scnr.nextInt();

    	        System.out.printf("%nEnter 'Y' if the ship is in service"
        			             + "(any other key if not in service): ");
	            inService = Character.toUpperCase(scnr.next().charAt(0));
	    
	            if(inService == 'Y') {
        	    	isInService = true;
	            }
	            else {
         		    isInService = false;
	            }
	            addShipToList(newShipName,
	        	    	      balcony,
	    	    	          oceanView,
	    		              suite,
	    	     	          interior,
	        		          isInService);
	    
	            isShipInSystem = false;//reset boolean to false for next input.
	        }
        }
        
	    // Catch invalid input type.
	    catch(InputMismatchException excpt) {
            System.out.println("The following error message was reported:"); 		
		    System.out.println("Caught InputMismatchException: "
			                  + excpt.getMessage());
     	    System.out.println("Error occurred in method: addShip ");
     	    validInput.clearInputBuffer(scnr);
	    }
        catch(Exception excpt) {
            System.out.println("The following error message was reported:");
    	    System.out.println(excpt.getMessage());
     	    System.out.println("Error occurred in method: addShip ");
     	    validInput.clearInputBuffer(scnr); 	
        }
    }
    
/**
 * editShip - Edit an existing ship
 */
    public void editShip() {
        // This method does not need to be completed
        System.out.println("The \"Edit Ship\" feature is not yet implemented.");
    }

/**
 * getShip - Returns ship info on a given ship name or prints not in system
 * @param searchShip is a valid ship name
 * @return string is a valid ship name
 */
    public String getShip(String searchShip) {
        if (shipList.size() < 1) {
            System.out.println("\nThere are no ships in system.");
            return null;
        }

        for (Ship eachShip: shipList) {

            if(searchShip.compareTo(eachShip.getShipName()) == 0) {
                printDetailsColHeader();   	    	
                eachShip.printShipData();
                return searchShip;
            }
        }
        System.out.println(searchShip + " is not in the system.");
        return null;
    }
        
/**
 * printShipList - Prints a list of ships from the shipList ArrayList.
 * @param listType: There are three different outputs based on the listType
 *      String parameter:
 *          name - prints a list of ship names only
 *          active - prints a list of ship names that are "in service"
 *          full - prints tabbed data on all ships
 */
    public void printShipList(String listType) {
        if (shipList.size() < 1) {
            System.out.println("\nThere are no ships to print.");
            return;
        }
    
        if (listType == "name") {
             System.out.println("\n\nSHIP LIST - Name");
        	 
             for (int i = 0; i < shipList.size(); i++) {
             System.out.println(shipList.get(i));
             }
        }
        
        else if (listType == "active") {
            System.out.println("\n\nSHIP LIST - Active");
            printDetailsColHeader();
        
            for(Ship eachShip: shipList) {
        	    if(eachShip.getInService() == true)
        		    eachShip.printShipData();
            }
        }
        
        else if (listType == "full") {
            System.out.println("\n\nSHIP LIST - Full");
            printDetailsColHeader();
            for (Ship eachShip: shipList)
                eachShip.printShipData();
        }
        
        else
            System.out.println("\n\nError: List type not defined.");
    }
    
/**
 * shipActiveAvailable -Verifies that a ship is "in service" and available for a new cruise.
 *                     -Prints information if the ship is not valid for a new cruise.
 * @param cruiseShipName is a String that represents the name of the ship
 *        the user would like to assign to a new cruise.
 */
    public boolean shipActiveAvailable(String cruiseShipName, ArrayList<Cruise> cruiseList) {
	    ArrayList<String> shipActiveAvailable = new ArrayList<String>();
	    ArrayList<Cruise> cruises = cruiseList;

        for(Ship eachShip: shipList) {
        	if(eachShip.getInService() == true) {
                shipActiveAvailable.add(eachShip.getShipName());
   	        }
        }

    	for(Cruise eachCruise: cruises) {
		    for(String eachShip: shipActiveAvailable) {
	            if(eachShip.compareTo(eachCruise.getCruiseShipName()) == 0) {
	        	shipActiveAvailable.remove(eachShip);
	            }
	        }
	    }

    	if(shipActiveAvailable.size() == 0) {
	    	System.out.println("Currently there are no ships in service");
		    System.out.println("and available for a new cruise.  Please add");
		    System.out.println("a new ship that is in service and available.");
		    return false;
	    }
    	
	    else {
		    for(String eachShip: shipActiveAvailable) {
			    if(cruiseShipName.compareTo(eachShip) == 0) {
				    return true;
			    }
		    }
	    }
    	
		System.out.println("\nThat ship is currently on another cruise.");
		if(shipActiveAvailable.size() > 0) {
		    System.out.println("\nThe following ships are available and in service:");
		    for(String eachShip: shipActiveAvailable) {
		    	System.out.println(eachShip + "\n");
		    }
		}
		else {
			System.out.println("Currently there are no ships that are " + 
			                   "in service and available.");
		}
	    return false;
    } 

/**
 * printDetailsColHeader - Prints the column headers for ship details.
 */
    public void printDetailsColHeader() {
        System.out.println("-----------------------------------------------");
        System.out.println("                    Number of Rooms     In");
        System.out.print("SHIP NAME           Bal OV  Ste Int     Service");
        System.out.println("\n-----------------------------------------------");
    }
}