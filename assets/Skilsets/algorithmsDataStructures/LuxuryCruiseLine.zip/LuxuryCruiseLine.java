/**********************************************************************
 * Program:    LuxuryCruiseLine.Java
 * Programmer: Lawrence Linnell
 * University: Southern New Hampshire University
 * Date:       January 24, 2021
 * 
 * About:
 * This program is designed for a luxury cruise line company to track
 * passengers, cruise ships and active cruises.  A menu is displayed
 * to the user which allows for adding, editing and viewing of cruise
 * ships, passengers and active cruises within the system.
 * 
 */

import java.util.Scanner;

/**
 * LuxuryCruiseLine class contains the main driver of the cruise ship program.
 * @author Lawrence Linnell
 */
public class LuxuryCruiseLine {

/**
 *  Main Program 
 */
    public static void main(String[] args) {
    	// Variables
        char menuOption = '?';    	
    	Scanner scnr = new Scanner(System.in);
    	
        // Create Objects for CruiseList, ShipList and PassengerList
        ValidInput validInput;   	
        ShipList shipList;
        CruiseList cruiseList = null;
        PassengerList passengerList;
        Sort quickSort;

        validInput = new ValidInput();   	
        shipList = new ShipList(validInput);
        cruiseList = new CruiseList(validInput, shipList);
        passengerList = new PassengerList(validInput);
        quickSort = new Sort();
        shipList = quickSort.sortShips(shipList);
        
        /* Accepts and validates user input and takes the appropriate action.
    	 * Provides appropriate user feedback and redisplays the menu as needed.
         */
        do{
        	try {
                displayMenu();
                menuOption = Character.toUpperCase(scnr.next().charAt(0));
                processMenuOption(menuOption, scnr, shipList, cruiseList,
                		          passengerList, validInput, quickSort);
        	}
        	catch(Exception excpt) {
        		System.out.println(excpt.getMessage());
        		System.out.println("Please re-enter valid input.");
        	}
        }while(menuOption != 'X');
        scnr.close();
    }
    
/**
 *  displayMenu - Display text-based menu.
 */
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\tLuxury Ocean Cruise Outings");
        System.out.println("\t\tSystem Menu\n");
        System.out.println("[1] Add Ship            [A] Print Ship Names");
        System.out.println("[2] Edit Ship           [B] Print Ship In Service List");
        System.out.println("[3] Add Cruise          [C] Print Ship Full List");
        System.out.println("[4] Edit Cruise         [D] Print Cruise List");
        System.out.println("[5] Add Passenger       [E] Print Cruise Details");
        System.out.println("[6] Edit Passenger      [F] Print Passenger List");
        System.out.println("[x] Exit System         [S] Search");
        System.out.println("\nEnter a menu selection: ");
    }

/**
 *  processMenuOption - Process user input with the correlating menu option.
 *
 *  @param menuOption is a character that represents an option from the menu.
 *  @param scnr is a valid Scanner object.
 *  @param shipList is an ArrayList of Ship objects.   
 */
    public static void processMenuOption(char menuOption,
    		                             Scanner scnr,
    		                             ShipList shipList,
    		                             CruiseList cruiseList,
    		                             PassengerList passengerList,
    		                             ValidInput validInput,
    		                             Sort quickSort) {
    	menuOption = Character.toUpperCase(menuOption);
    	switch(menuOption) {
    	    case '1':
    	    	shipList.addShip(scnr);
    	        shipList = quickSort.sortShips(shipList);
    		    break;
    		    
    	    case '2':
    	    	shipList.editShip();
    	        shipList = quickSort.sortShips(shipList);
    		    break;
    		    
    	    case '3':
    	    	cruiseList.addCruise(scnr, shipList);
    		    break;
    		    
    	    case '4':
    	    	cruiseList.editCruise();
    	    	break;
    	    	
    	    case '5':
    	    	passengerList.addPassenger(cruiseList);
    	    	break;
    	    	
    	    case '6':
    	    	passengerList.editPassenger();
    	    	break;
    	    	
    	    case 'A':
    	    	shipList.printShipList("name");
    	    	break;
    	    	
    	    case 'B':
    	    	shipList.printShipList("active");
    	    	break;
    	    	
    	    case 'C':
    	    	shipList.printShipList("full");
    	    	break;
    	    	
    	    case 'D':
    	    	cruiseList.printCruiseList("list");
    	    	break;
    	    	
    	    case 'E':
    	    	cruiseList.printCruiseList("details");
    	    	break;
    	    	
    	    case 'F':
    	    	passengerList.printPassengerList();
    	    	break;
    	    	
    	    case 'S':
    	    	int searchOption = 0;
    	    	String searchName = "?";

    	    	System.out.println("What do you want to search for?");
      	    	System.out.println("[1] Cruise [2] Ship [3] Passenger");	    	
    	    	System.out.println("Please enter(1, 2 or 3):");
    	    	
    	    	// Get user input
    	    	searchOption = Character.toUpperCase(scnr.next().charAt(0));
    	    	// Process Input
    	    	switch(searchOption) {
    	    	    case '1': // Search Cruise
    	    	    	System.out.println("Please enter the name of the cruise:");
    	    	    	validInput.clearInputBuffer(scnr);
    	    	    	searchName = scnr.nextLine();	
    	    	    	cruiseList.getCruise(searchName);    
    	    		    break;
    	    		    
    	    	    case '2': // Search Ship
    	    	    	System.out.println("Please enter the name of the ship:");
    	    	    	validInput.clearInputBuffer(scnr);
    	    	    	searchName = scnr.nextLine();
    	    	    	shipList.getShip(searchName);
    	    		    break;
    	    		    
    	    	    case '3': // Search Passenger
    	    	    	System.out.println("Please enter the name of the passenger:");
    	    	    	validInput.clearInputBuffer(scnr);
    	    	    	searchName = scnr.nextLine();
    	    	    	passengerList.getPassenger(searchName);
    	    		    break;
    	    		    
    	    	    default:
    	    		    System.out.println("That is not a valid option. Returning to Main Menu");
    	    		    break;
    	    	}	
    	        break;
    	    	
    	    case 'X':
    	    	System.out.println("EXIT");
    	    	break;
    	    	
    	    default:
    	    	System.out.println("Enter an option from the menu.");
    	    	break;
    	}
    	// Prompt user to press enter to continue if menuOption is not equal to X
    	if(menuOption != 'X') {
    		if(menuOption != 'S'){
    	        validInput.clearInputBuffer(scnr);
    		}
    	    validInput.pressEnterToContinue(scnr);
    	}
    }
}
